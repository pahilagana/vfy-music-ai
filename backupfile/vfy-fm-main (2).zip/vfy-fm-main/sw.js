self.addEventListener('fetch', function (event) {});

